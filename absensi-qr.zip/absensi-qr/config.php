<?php
session_start();
date_default_timezone_set('Asia/Jakarta');

const DB_HOST = 'localhost';
const DB_NAME = 'absensi_qr';
const DB_USER = 'root';
const DB_PASS = '';
const JAM_MASUK = '08:00:00';      // lewat jam ini = terlambat
const HARI_KERJA = [1,2,3,4,5];    // 1=Senin ... 7=Minggu

if (basename($_SERVER['PHP_SELF']) !== 'install.php') {
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        exit('Koneksi database gagal. Jalankan install.php terlebih dahulu.');
    }
}

function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">'; }
function csrf_check(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Sesi tidak valid. Muat ulang halaman.'); }
}
function set_flash(string $t, string $m): void { $_SESSION['flash'] = ['t' => $t, 'm' => $m]; }
function get_flash(): ?array { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }
function is_admin(): bool { return ($_SESSION['user']['role'] ?? '') === 'admin'; }
function login_required(): void { if (empty($_SESSION['user'])) { header('Location: login.php'); exit; } }
function admin_required(): void { login_required(); if (!is_admin()) { header('Location: index.php'); exit; } }
function nama_bulan(): array { return [1=>'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember']; }
function nama_hari(string $tgl): string { return ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'][(int)date('w', strtotime($tgl))]; }
function tgl_id(string $tgl): string { return date('d/m/Y', strtotime($tgl)); }

function label_status(string $s): string {
    $m = ['hadir'=>['Hadir','b-ok'],'terlambat'=>['Terlambat','b-warn'],'izin'=>['Izin','b-info'],
          'sakit'=>['Sakit','b-info'],'alpa'=>['Tidak masuk','b-bad'],'libur'=>['Libur','b-gray'],'belum'=>['Belum absen','b-gray']];
    [$t, $c] = $m[$s] ?? [$s, 'b-gray'];
    return '<span class="badge ' . $c . '">' . $t . '</span>';
}

/** Status per karyawan per tanggal. Hasil: [user_id][Y-m-d] => ['s','masuk','pulang','ket'] */
function ambil_status(PDO $pdo, string $dari, string $sampai, array $users): array {
    if (!$users) return [];
    $ids = array_column($users, 'id');
    $in = implode(',', array_fill(0, count($ids), '?'));

    $st = $pdo->prepare("SELECT user_id,tanggal,jam_masuk,jam_pulang,status FROM absensi WHERE tanggal BETWEEN ? AND ? AND user_id IN ($in)");
    $st->execute(array_merge([$dari, $sampai], $ids));
    $abs = [];
    foreach ($st as $r) $abs[$r['user_id']][$r['tanggal']] = $r;

    $st = $pdo->prepare("SELECT user_id,tanggal,jenis,keterangan FROM izin WHERE status='disetujui' AND tanggal BETWEEN ? AND ? AND user_id IN ($in)");
    $st->execute(array_merge([$dari, $sampai], $ids));
    $izn = [];
    foreach ($st as $r) $izn[$r['user_id']][$r['tanggal']] = $r;

    $today = date('Y-m-d');
    $out = [];
    foreach ($users as $u) {
        $uid = $u['id'];
        $mulai = max($dari, substr($u['created_at'], 0, 10));
        for ($d = strtotime($mulai); $d <= strtotime($sampai); $d = strtotime('+1 day', $d)) {
            $tgl = date('Y-m-d', $d);
            if ($tgl > $today) break;
            if (isset($abs[$uid][$tgl])) {
                $a = $abs[$uid][$tgl];
                $out[$uid][$tgl] = ['s'=>$a['status'],'masuk'=>$a['jam_masuk'],'pulang'=>$a['jam_pulang'],'ket'=>''];
            } elseif (isset($izn[$uid][$tgl])) {
                $i = $izn[$uid][$tgl];
                $out[$uid][$tgl] = ['s'=>$i['jenis'],'masuk'=>null,'pulang'=>null,'ket'=>$i['keterangan']];
            } elseif (!in_array((int)date('N', $d), HARI_KERJA, true)) {
                $out[$uid][$tgl] = ['s'=>'libur','masuk'=>null,'pulang'=>null,'ket'=>''];
            } elseif ($tgl === $today) {
                $out[$uid][$tgl] = ['s'=>'belum','masuk'=>null,'pulang'=>null,'ket'=>''];
            } else {
                $out[$uid][$tgl] = ['s'=>'alpa','masuk'=>null,'pulang'=>null,'ket'=>''];
            }
        }
    }
    return $out;
}
function hitung(array $hari): array {
    $c = ['hadir'=>0,'terlambat'=>0,'izin'=>0,'sakit'=>0,'alpa'=>0];
    foreach ($hari as $h) if (isset($c[$h['s']])) $c[$h['s']]++;
    return $c;
}
function persen(array $c): string {
    $t = array_sum($c);
    return $t ? round(($c['hadir'] + $c['terlambat']) / $t * 100) . '%' : '-';
}
