<?php
require 'config.php'; login_required();
$judul = 'Dashboard'; $u = $_SESSION['user']; $today = date('Y-m-d');
require 'header.php';

if (is_admin()):
    $users = $pdo->query("SELECT id,nama,created_at FROM users WHERE role='karyawan' AND aktif=1")->fetchAll();
    $st = ambil_status($pdo, $today, $today, $users);
    $c = ['hadir'=>0,'terlambat'=>0,'izin'=>0,'sakit'=>0,'belum'=>0,'alpa'=>0,'libur'=>0];
    foreach ($users as $x) { $s = $st[$x['id']][$today]['s'] ?? null; if ($s) $c[$s]++; }
    $q = $pdo->prepare("SELECT a.*,u.nama FROM absensi a JOIN users u ON u.id=a.user_id WHERE a.tanggal=? ORDER BY a.jam_masuk DESC LIMIT 10");
    $q->execute([$today]); $terbaru = $q->fetchAll();
    $menunggu = (int)$pdo->query("SELECT COUNT(*) FROM izin WHERE status='menunggu'")->fetchColumn();
?>
<div class="page-head"><h1>Dashboard</h1><span class="muted"><?= nama_hari($today) ?>, <?= tgl_id($today) ?></span></div>
<div class="cards">
  <div class="card"><span>Karyawan aktif</span><b><?= count($users) ?></b></div>
  <div class="card ok"><span>Masuk hari ini</span><b><?= $c['hadir'] + $c['terlambat'] ?></b></div>
  <div class="card info"><span>Izin / sakit</span><b><?= $c['izin'] + $c['sakit'] ?></b></div>
  <div class="card bad"><span>Belum absen / tidak masuk</span><b><?= $c['belum'] + $c['alpa'] ?></b></div>
</div>
<?php if ($menunggu): ?><div class="alert alert-err"><?= $menunggu ?> pengajuan izin menunggu persetujuan. <a href="izin.php">Tinjau</a></div><?php endif; ?>
<section class="panel"><h2>Scan terbaru hari ini</h2>
<?php if (!$terbaru): ?><p class="muted">Belum ada yang absen hari ini.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Nama</th><th>Masuk</th><th>Pulang</th><th>Status</th></tr></thead><tbody>
<?php foreach ($terbaru as $r): ?><tr><td><?= e($r['nama']) ?></td><td><?= e(substr($r['jam_masuk'],0,5)) ?></td>
<td><?= $r['jam_pulang'] ? e(substr($r['jam_pulang'],0,5)) : '-' ?></td><td><?= label_status($r['status']) ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<?php else:
    $me = [['id' => $u['id'], 'nama' => $u['nama'], 'created_at' => $pdo->query("SELECT created_at FROM users WHERE id=" . (int)$u['id'])->fetchColumn()]];
    $awal = date('Y-m-01');
    $st = ambil_status($pdo, $awal, $today, $me);
    $hari = $st[$u['id']] ?? [];
    $hi = $hari[$today] ?? ['s' => 'belum', 'masuk' => null, 'pulang' => null, 'ket' => ''];
    $c = hitung($hari);
?>
<div class="page-head"><h1>Halo, <?= e($u['nama']) ?></h1><span class="muted"><?= nama_hari($today) ?>, <?= tgl_id($today) ?></span></div>
<section class="panel"><h2>Status hari ini</h2>
<p><?= label_status($hi['s']) ?>
<?php if ($hi['masuk']): ?> Masuk <b><?= e(substr($hi['masuk'],0,5)) ?></b> &middot; Pulang <b><?= $hi['pulang'] ? e(substr($hi['pulang'],0,5)) : '-' ?></b><?php endif; ?></p>
<a class="btn" href="kartu.php">Tampilkan kartu QR saya</a></section>
<div class="cards">
  <div class="card ok"><span>Hadir bulan ini</span><b><?= $c['hadir'] + $c['terlambat'] ?></b></div>
  <div class="card warn"><span>Terlambat</span><b><?= $c['terlambat'] ?></b></div>
  <div class="card info"><span>Izin / sakit</span><b><?= $c['izin'] + $c['sakit'] ?></b></div>
  <div class="card bad"><span>Tidak masuk</span><b><?= $c['alpa'] ?></b></div>
</div>
<?php endif; require 'footer.php'; ?>
