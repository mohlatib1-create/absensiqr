ABSENSI QR - cara pasang (XAMPP)
1. Salin folder "absensi-qr" ke C:\xampp\htdocs\
2. Nyalakan Apache dan MySQL di XAMPP Control Panel.
3. Buka http://localhost/absensi-qr/install.php lalu klik "Pasang sekarang".
4. Login: admin / admin123 (segera ganti), lalu hapus install.php.
5. Tambah karyawan di menu "Data karyawan", cetak "Kartu QR" masing-masing.
6. Buka menu "Scan QR" (di komputer/HP petugas) dan arahkan kamera ke QR karyawan.

Pengaturan (config.php): JAM_MASUK = batas terlambat, HARI_KERJA = hari kerja (1=Senin..7=Minggu).
Pustaka QR dimuat dari cdnjs, jadi perlu koneksi internet saat membuka Scan QR dan Kartu QR.
Kamera hanya jalan di http://localhost atau HTTPS.
