<?php
require 'config.php';
$pesan = ''; $ok = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `" . DB_NAME . "`");
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            nama VARCHAR(100) NOT NULL,
            username VARCHAR(50) NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin','karyawan') NOT NULL DEFAULT 'karyawan',
            jabatan VARCHAR(100) NULL,
            token CHAR(32) NOT NULL,
            aktif TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY uq_username (username), UNIQUE KEY uq_token (token)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS absensi (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            tanggal DATE NOT NULL,
            jam_masuk TIME NOT NULL,
            jam_pulang TIME NULL,
            status ENUM('hadir','terlambat') NOT NULL DEFAULT 'hadir',
            PRIMARY KEY (id), UNIQUE KEY uq_user_tgl (user_id, tanggal), KEY idx_tgl (tanggal),
            CONSTRAINT fk_abs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("CREATE TABLE IF NOT EXISTS izin (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            tanggal DATE NOT NULL,
            jenis ENUM('izin','sakit') NOT NULL DEFAULT 'izin',
            keterangan VARCHAR(255) NOT NULL DEFAULT '',
            status ENUM('menunggu','disetujui','ditolak') NOT NULL DEFAULT 'menunggu',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id), UNIQUE KEY uq_izin (user_id, tanggal),
            CONSTRAINT fk_izin_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $n = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
        if ($n === 0) {
            $pdo->prepare("INSERT INTO users (nama,username,password,role,token) VALUES (?,?,?,?,?)")
                ->execute(['Administrator', 'admin', password_hash('admin123', PASSWORD_DEFAULT), 'admin', bin2hex(random_bytes(16))]);
        }
        $ok = true;
        $pesan = 'Instalasi berhasil. Login dengan username admin, password admin123. Segera ganti password dan hapus file install.php.';
    } catch (PDOException $e) {
        $pesan = 'Gagal: ' . $e->getMessage();
    }
}
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Instalasi Absensi QR</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth"><div class="auth-box">
<h1>Instalasi Absensi QR</h1>
<p class="muted">Membuat database <b><?= e(DB_NAME) ?></b>, tabel, dan akun admin.</p>
<?php if ($pesan): ?><div class="alert <?= $ok ? 'alert-ok' : 'alert-err' ?>"><?= e($pesan) ?></div><?php endif; ?>
<?php if ($ok): ?><a class="btn" href="login.php">Ke halaman login</a>
<?php else: ?><form method="post"><button class="btn" type="submit">Pasang sekarang</button></form><?php endif; ?>
</div></body></html>
