<?php
$u = $_SESSION['user']; $cur = basename($_SERVER['PHP_SELF']); $flash = get_flash();
function nav_link(string $f, string $l, string $cur): string {
    return '<a href="' . $f . '"' . ($cur === $f ? ' class="active"' : '') . '>' . $l . '</a>';
}
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($judul ?? 'Absensi QR') ?> | Absensi QR</title><link rel="stylesheet" href="assets/style.css"></head>
<body><div class="layout">
<aside class="sidebar">
  <div class="brand">Absensi QR</div>
  <nav>
    <?= nav_link('index.php', 'Dashboard', $cur) ?>
    <?php if (is_admin()): ?>
      <?= nav_link('scan.php', 'Scan QR', $cur) ?>
      <?= nav_link('karyawan.php', 'Data karyawan', $cur) ?>
      <?= nav_link('laporan_harian.php', 'Laporan harian', $cur) ?>
      <?= nav_link('laporan_bulanan.php', 'Laporan bulanan', $cur) ?>
      <?= nav_link('izin.php', 'Izin / sakit', $cur) ?>
    <?php else: ?>
      <?= nav_link('kartu.php', 'Kartu QR saya', $cur) ?>
      <?= nav_link('izin.php', 'Ajukan izin', $cur) ?>
      <?= nav_link('laporan_bulanan.php', 'Rekap bulanan', $cur) ?>
    <?php endif; ?>
  </nav>
  <div class="userbox"><strong><?= e($u['nama']) ?></strong><span class="muted"><?= e($u['role']) ?></span>
    <a class="btn btn-light btn-sm" href="logout.php">Keluar</a></div>
</aside>
<main class="content">
<?php if ($flash): ?><div class="alert alert-<?= $flash['t'] === 'ok' ? 'ok' : 'err' ?>"><?= e($flash['m']) ?></div><?php endif; ?>
