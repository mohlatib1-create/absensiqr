<?php
require 'config.php';
if (!empty($_SESSION['user'])) { header('Location: index.php'); exit; }
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $st = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $st->execute([trim($_POST['username'] ?? '')]);
    $r = $st->fetch();
    if ($r && $r['aktif'] && password_verify($_POST['password'] ?? '', $r['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int)$r['id'], 'nama' => $r['nama'], 'role' => $r['role']];
        header('Location: index.php'); exit;
    }
    $err = 'Username atau password salah, atau akun nonaktif.';
}
?><!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | Absensi QR</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="auth"><div class="auth-box">
<h1>Absensi QR</h1><p class="muted">Silakan masuk</p>
<?php if ($err): ?><div class="alert alert-err"><?= e($err) ?></div><?php endif; ?>
<form method="post"><?= csrf_field() ?>
<label>Username<input name="username" required autofocus></label>
<label>Password<input type="password" name="password" required></label>
<button class="btn" type="submit">Masuk</button></form>
</div></body></html>
