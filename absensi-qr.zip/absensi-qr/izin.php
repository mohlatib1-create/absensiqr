<?php
require 'config.php'; login_required();
$judul = 'Izin / sakit'; $me = $_SESSION['user'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $aksi = $_POST['aksi'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    try {
        if ($aksi === 'ajukan') {
            $uid = is_admin() ? (int)($_POST['user_id'] ?? 0) : $me['id'];
            $tgl = $_POST['tanggal'] ?? ''; $jenis = $_POST['jenis'] ?? '';
            $ket = mb_substr(trim($_POST['keterangan'] ?? ''), 0, 255);
            $d = DateTime::createFromFormat('Y-m-d', $tgl);
            if (!$uid || !$d || $d->format('Y-m-d') !== $tgl || !in_array($jenis, ['izin', 'sakit'], true) || $ket === '')
                throw new RuntimeException('Lengkapi tanggal, jenis, dan keterangan.');
            $pdo->prepare("INSERT INTO izin (user_id,tanggal,jenis,keterangan,status) VALUES (?,?,?,?,?)")
                ->execute([$uid, $tgl, $jenis, $ket, is_admin() ? 'disetujui' : 'menunggu']);
            set_flash('ok', is_admin() ? 'Izin dicatat dan langsung disetujui.' : 'Pengajuan terkirim, menunggu persetujuan admin.');
        } elseif ($aksi === 'batal' && !is_admin()) {
            $pdo->prepare("DELETE FROM izin WHERE id=? AND user_id=? AND status='menunggu'")->execute([$id, $me['id']]);
            set_flash('ok', 'Pengajuan dibatalkan.');
        } elseif (in_array($aksi, ['setuju', 'tolak'], true) && is_admin()) {
            $pdo->prepare("UPDATE izin SET status=? WHERE id=?")->execute([$aksi === 'setuju' ? 'disetujui' : 'ditolak', $id]);
            set_flash('ok', 'Status pengajuan diperbarui.');
        }
    } catch (PDOException $ex) {
        set_flash('err', $ex->getCode() === '23000' ? 'Sudah ada pengajuan izin pada tanggal itu.' : 'Kesalahan database.');
    } catch (RuntimeException $ex) {
        set_flash('err', $ex->getMessage());
    }
    header('Location: izin.php'); exit;
}

if (is_admin()) {
    $rows = $pdo->query("SELECT i.*,u.nama FROM izin i JOIN users u ON u.id=i.user_id ORDER BY (i.status='menunggu') DESC, i.tanggal DESC LIMIT 200")->fetchAll();
    $daftar = $pdo->query("SELECT id,nama FROM users WHERE role='karyawan' AND aktif=1 ORDER BY nama")->fetchAll();
} else {
    $st = $pdo->prepare("SELECT i.*,? AS nama FROM izin i WHERE user_id=? ORDER BY tanggal DESC LIMIT 100");
    $st->execute([$me['nama'], $me['id']]); $rows = $st->fetchAll();
}
$badge = ['menunggu' => 'b-warn', 'disetujui' => 'b-ok', 'ditolak' => 'b-bad'];
require 'header.php';
?>
<div class="page-head"><h1><?= is_admin() ? 'Izin / sakit karyawan' : 'Ajukan izin / sakit' ?></h1></div>
<section class="panel"><h2><?= is_admin() ? 'Catat izin untuk karyawan' : 'Form pengajuan' ?></h2>
<form method="post" class="grid-form"><?= csrf_field() ?><input type="hidden" name="aksi" value="ajukan">
  <?php if (is_admin()): ?><select name="user_id" required><option value="">Pilih karyawan</option>
    <?php foreach ($daftar as $d): ?><option value="<?= (int)$d['id'] ?>"><?= e($d['nama']) ?></option><?php endforeach; ?></select><?php endif; ?>
  <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
  <select name="jenis"><option value="izin">Izin</option><option value="sakit">Sakit</option></select>
  <input name="keterangan" placeholder="Keterangan" maxlength="255" required>
  <button class="btn" type="submit"><?= is_admin() ? 'Catat' : 'Kirim' ?></button>
</form></section>
<section class="panel"><h2>Riwayat</h2>
<?php if (!$rows): ?><p class="muted">Belum ada data.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Nama</th><th>Jenis</th><th>Keterangan</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr>
  <td><?= tgl_id($r['tanggal']) ?></td><td><?= e($r['nama']) ?></td><td><?= e(ucfirst($r['jenis'])) ?></td><td><?= e($r['keterangan']) ?></td>
  <td><span class="badge <?= $badge[$r['status']] ?>"><?= e(ucfirst($r['status'])) ?></span></td>
  <td class="actions">
  <?php if (is_admin() && $r['status'] === 'menunggu'): ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="setuju"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="link" type="submit">Setujui</button></form>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="tolak"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="link danger" type="submit">Tolak</button></form>
  <?php elseif (!is_admin() && $r['status'] === 'menunggu'): ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="batal"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="link danger" type="submit">Batalkan</button></form>
  <?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<?php require 'footer.php'; ?>
