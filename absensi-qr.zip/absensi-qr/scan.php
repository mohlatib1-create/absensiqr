<?php
require 'config.php'; admin_required();
$judul = 'Scan QR';
require 'header.php';
?>
<div class="page-head"><h1>Scan QR absensi</h1></div>
<section class="panel">
  <p class="muted">Arahkan kamera ke QR karyawan. Scan pertama hari itu = masuk, scan kedua = pulang. Kamera hanya bisa dipakai lewat <b>localhost</b> atau HTTPS.</p>
  <div id="reader" class="reader"></div>
  <div id="hasil" class="scan-result">Menunggu scan...</div>
  <form id="manual" class="inline-form">
    <input id="tokenManual" placeholder="Atau ketik kode QR secara manual" autocomplete="off">
    <button class="btn btn-light" type="submit">Kirim</button>
  </form>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.8/html5-qrcode.min.js"></script>
<script>
const csrf = <?= json_encode(csrf_token()) ?>;
let kunci = false;
function esc(s){ const d = document.createElement('div'); d.textContent = s ?? ''; return d.innerHTML; }
function tampil(j){
  const b = document.getElementById('hasil');
  b.className = 'scan-result ' + (j.ok ? 'ok' : 'err');
  b.innerHTML = '<strong>' + esc(j.pesan) + '</strong>' + (j.nama ? '<div>' + esc(j.nama) + ' &middot; ' + esc(j.jam || '') + '</div>' : '');
}
async function kirim(token){
  if (kunci || !token) return;
  kunci = true;
  try {
    const fd = new FormData(); fd.append('token', token); fd.append('csrf', csrf);
    const r = await fetch('api_scan.php', { method: 'POST', body: fd });
    tampil(await r.json());
  } catch (e) { tampil({ ok: false, pesan: 'Gagal menghubungi server.' }); }
  setTimeout(() => { kunci = false; }, 2500);
}
document.getElementById('manual').addEventListener('submit', e => {
  e.preventDefault(); kirim(document.getElementById('tokenManual').value.trim()); e.target.reset();
});
const scanner = new Html5Qrcode('reader');
scanner.start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 250, height: 250 } }, t => kirim(t), () => {})
  .catch(err => { document.getElementById('hasil').textContent = 'Kamera tidak bisa dibuka: ' + err; });
</script>
<?php require 'footer.php'; ?>
