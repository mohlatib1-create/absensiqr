<?php
require 'config.php'; login_required();
$id = (int)($_GET['id'] ?? $_SESSION['user']['id']);
if (!is_admin() && $id !== (int)$_SESSION['user']['id']) { http_response_code(403); exit('Tidak diizinkan.'); }
$st = $pdo->prepare("SELECT id,nama,jabatan,token FROM users WHERE id=? AND role='karyawan'");
$st->execute([$id]);
$k = $st->fetch();
if (!$k) { set_flash('err', 'Kartu QR hanya untuk akun karyawan.'); header('Location: index.php'); exit; }
$judul = 'Kartu QR';
require 'header.php';
?>
<div class="page-head"><h1>Kartu QR</h1><button class="btn btn-light no-print" onclick="window.print()">Cetak</button></div>
<section class="panel kartu">
  <h2><?= e($k['nama']) ?></h2>
  <p class="muted"><?= e($k['jabatan'] ?: 'Karyawan') ?></p>
  <div id="qr"></div>
  <p class="muted small">Tunjukkan QR ini ke petugas saat masuk dan pulang.</p>
</section>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>new QRCode(document.getElementById('qr'), { text: <?= json_encode($k['token']) ?>, width: 240, height: 240 });</script>
<?php require 'footer.php'; ?>
