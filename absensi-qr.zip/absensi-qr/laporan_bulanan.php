<?php
require 'config.php'; login_required();
$judul = 'Laporan bulanan';
$bulan = max(1, min(12, (int)($_GET['bulan'] ?? date('n'))));
$tahun = max(2000, min(2100, (int)($_GET['tahun'] ?? date('Y'))));
$dari = sprintf('%04d-%02d-01', $tahun, $bulan);
$sampai = date('Y-m-t', strtotime($dari));
$uid = is_admin() ? (int)($_GET['uid'] ?? 0) : (int)$_SESSION['user']['id'];

if ($uid) {
    $q = $pdo->prepare("SELECT id,nama,jabatan,created_at FROM users WHERE id=? AND role='karyawan'");
    $q->execute([$uid]); $users = $q->fetchAll();
} else {
    $users = $pdo->query("SELECT id,nama,jabatan,created_at FROM users WHERE role='karyawan' ORDER BY nama")->fetchAll();
}
$st = ambil_status($pdo, $dari, $sampai, $users);
$namaBulan = nama_bulan()[$bulan];

if (isset($_GET['export'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="laporan-' . $tahun . '-' . sprintf('%02d', $bulan) . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    if ($uid && $users) {
        fputcsv($o, ['Tanggal', 'Hari', 'Status', 'Masuk', 'Pulang', 'Keterangan']);
        foreach ($st[$uid] ?? [] as $t => $r) fputcsv($o, [$t, nama_hari($t), $r['s'], $r['masuk'], $r['pulang'], $r['ket']]);
    } else {
        fputcsv($o, ['Nama', 'Jabatan', 'Hadir', 'Terlambat', 'Izin', 'Sakit', 'Tidak masuk', 'Kehadiran']);
        foreach ($users as $u) { $c = hitung($st[$u['id']] ?? []);
            fputcsv($o, [$u['nama'], $u['jabatan'], $c['hadir'], $c['terlambat'], $c['izin'], $c['sakit'], $c['alpa'], persen($c)]); }
    }
    fclose($o); exit;
}
require 'header.php';
$qs = ['bulan' => $bulan, 'tahun' => $tahun] + ($uid && is_admin() ? ['uid' => $uid] : []);
?>
<div class="page-head"><h1>Laporan bulanan</h1>
<form method="get" class="inline-form no-print">
  <?php if ($uid && is_admin()): ?><input type="hidden" name="uid" value="<?= $uid ?>"><?php endif; ?>
  <select name="bulan"><?php foreach (nama_bulan() as $n => $nm): ?><option value="<?= $n ?>" <?= $n === $bulan ? 'selected' : '' ?>><?= $nm ?></option><?php endforeach; ?></select>
  <input type="number" name="tahun" value="<?= $tahun ?>" min="2000" max="2100" style="width:90px">
  <button class="btn btn-light" type="submit">Tampilkan</button>
  <a class="btn btn-light" href="?<?= e(http_build_query($qs + ['export' => 1])) ?>">Unduh CSV</a>
  <button class="btn btn-light" type="button" onclick="window.print()">Cetak</button>
</form></div>
<p class="muted">Periode <?= $namaBulan ?> <?= $tahun ?>. Hari libur: Sabtu dan Minggu. Hari yang belum lewat tidak dihitung.</p>

<?php if ($uid && $users): $u = $users[0]; $hari = $st[$uid] ?? []; $c = hitung($hari); ?>
<h2><?= e($u['nama']) ?> <span class="muted small"><?= e($u['jabatan']) ?></span></h2>
<?php if (is_admin()): ?><p class="no-print"><a href="?<?= e(http_build_query(['bulan' => $bulan, 'tahun' => $tahun])) ?>">&larr; Kembali ke semua karyawan</a></p><?php endif; ?>
<div class="cards">
  <div class="card ok"><span>Hadir</span><b><?= $c['hadir'] ?></b></div>
  <div class="card warn"><span>Terlambat</span><b><?= $c['terlambat'] ?></b></div>
  <div class="card info"><span>Izin / sakit</span><b><?= $c['izin'] + $c['sakit'] ?></b></div>
  <div class="card bad"><span>Tidak masuk</span><b><?= $c['alpa'] ?></b></div>
  <div class="card"><span>Kehadiran</span><b><?= persen($c) ?></b></div>
</div>
<section class="panel"><div class="table-wrap"><table>
<thead><tr><th>Tanggal</th><th>Hari</th><th>Status</th><th>Masuk</th><th>Pulang</th><th>Keterangan</th></tr></thead><tbody>
<?php foreach ($hari as $t => $r): ?><tr><td><?= tgl_id($t) ?></td><td><?= nama_hari($t) ?></td><td><?= label_status($r['s']) ?></td>
<td><?= $r['masuk'] ? e(substr($r['masuk'], 0, 5)) : '-' ?></td><td><?= $r['pulang'] ? e(substr($r['pulang'], 0, 5)) : '-' ?></td><td><?= e($r['ket']) ?></td></tr>
<?php endforeach; if (!$hari): ?><tr><td colspan="6" class="muted">Belum ada data pada periode ini.</td></tr><?php endif; ?>
</tbody></table></div></section>

<?php else: ?>
<section class="panel"><div class="table-wrap"><table>
<thead><tr><th>Nama</th><th>Jabatan</th><th>Hadir</th><th>Terlambat</th><th>Izin</th><th>Sakit</th><th>Tidak masuk</th><th>Kehadiran</th><th class="no-print"></th></tr></thead><tbody>
<?php foreach ($users as $u): $c = hitung($st[$u['id']] ?? []); ?>
<tr><td><?= e($u['nama']) ?></td><td><?= e($u['jabatan'] ?: '-') ?></td><td><?= $c['hadir'] ?></td><td><?= $c['terlambat'] ?></td>
<td><?= $c['izin'] ?></td><td><?= $c['sakit'] ?></td><td><?= $c['alpa'] ?></td><td><?= persen($c) ?></td>
<td class="no-print"><a href="?<?= e(http_build_query(['bulan' => $bulan, 'tahun' => $tahun, 'uid' => $u['id']])) ?>">Detail</a></td></tr>
<?php endforeach; if (!$users): ?><tr><td colspan="9" class="muted">Belum ada karyawan.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php endif; require 'footer.php'; ?>
