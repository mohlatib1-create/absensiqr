<?php
require 'config.php'; admin_required();
$judul = 'Laporan harian';
$tgl = $_GET['tanggal'] ?? date('Y-m-d');
$d = DateTime::createFromFormat('Y-m-d', $tgl);
if (!$d || $d->format('Y-m-d') !== $tgl) $tgl = date('Y-m-d');

$users = $pdo->query("SELECT id,nama,jabatan,created_at FROM users WHERE role='karyawan' AND aktif=1 ORDER BY nama")->fetchAll();
$st = ambil_status($pdo, $tgl, $tgl, $users);
$c = ['masuk' => 0, 'izin' => 0, 'tidak' => 0, 'belum' => 0];
foreach ($users as $u) {
    $s = $st[$u['id']][$tgl]['s'] ?? null;
    if (in_array($s, ['hadir', 'terlambat'], true)) $c['masuk']++;
    elseif (in_array($s, ['izin', 'sakit'], true)) $c['izin']++;
    elseif ($s === 'alpa') $c['tidak']++;
    elseif ($s === 'belum') $c['belum']++;
}
require 'header.php';
?>
<div class="page-head"><h1>Laporan harian</h1>
<form method="get" class="inline-form no-print"><input type="date" name="tanggal" value="<?= e($tgl) ?>" max="<?= date('Y-m-d') ?>"><button class="btn btn-light" type="submit">Tampilkan</button>
<button class="btn btn-light" type="button" onclick="window.print()">Cetak</button></form></div>
<p class="muted"><?= nama_hari($tgl) ?>, <?= tgl_id($tgl) ?></p>
<div class="cards">
  <div class="card ok"><span>Masuk</span><b><?= $c['masuk'] ?></b></div>
  <div class="card info"><span>Izin / sakit</span><b><?= $c['izin'] ?></b></div>
  <div class="card bad"><span>Tidak masuk</span><b><?= $c['tidak'] ?></b></div>
  <div class="card"><span>Belum absen</span><b><?= $c['belum'] ?></b></div>
</div>
<section class="panel"><div class="table-wrap"><table>
<thead><tr><th>Nama</th><th>Jabatan</th><th>Status</th><th>Masuk</th><th>Pulang</th><th>Keterangan</th></tr></thead><tbody>
<?php foreach ($users as $u): $r = $st[$u['id']][$tgl] ?? null; ?>
<tr><td><?= e($u['nama']) ?></td><td><?= e($u['jabatan'] ?: '-') ?></td>
<td><?= $r ? label_status($r['s']) : '-' ?></td>
<td><?= $r && $r['masuk'] ? e(substr($r['masuk'], 0, 5)) : '-' ?></td>
<td><?= $r && $r['pulang'] ? e(substr($r['pulang'], 0, 5)) : '-' ?></td>
<td><?= e($r['ket'] ?? '') ?></td></tr>
<?php endforeach; if (!$users): ?><tr><td colspan="6" class="muted">Belum ada karyawan aktif.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php require 'footer.php'; ?>
