<?php
require 'config.php';
header('Content-Type: application/json; charset=utf-8');
function out(array $a): void { echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }

if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') out(['ok' => false, 'pesan' => 'Hanya admin yang boleh memindai.']);
if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) out(['ok' => false, 'pesan' => 'Sesi tidak valid. Muat ulang halaman.']);

$token = trim($_POST['token'] ?? '');
$st = $pdo->prepare("SELECT id,nama FROM users WHERE token=? AND role='karyawan' AND aktif=1");
$st->execute([$token]);
$k = $st->fetch();
if (!$k) out(['ok' => false, 'pesan' => 'QR tidak dikenali atau karyawan nonaktif.']);

$today = date('Y-m-d'); $now = date('H:i:s');

$st = $pdo->prepare("SELECT jenis FROM izin WHERE user_id=? AND tanggal=? AND status='disetujui'");
$st->execute([$k['id'], $today]);
if ($j = $st->fetchColumn()) out(['ok' => false, 'pesan' => 'Hari ini tercatat ' . $j . ' (disetujui).', 'nama' => $k['nama'], 'jam' => $now]);

$st = $pdo->prepare("SELECT * FROM absensi WHERE user_id=? AND tanggal=?");
$st->execute([$k['id'], $today]);
$a = $st->fetch();

if (!$a) {
    $status = $now > JAM_MASUK ? 'terlambat' : 'hadir';
    $pdo->prepare("INSERT INTO absensi (user_id,tanggal,jam_masuk,status) VALUES (?,?,?,?)")->execute([$k['id'], $today, $now, $status]);
    out(['ok' => true, 'pesan' => 'Absen MASUK berhasil' . ($status === 'terlambat' ? ' (terlambat)' : ''), 'nama' => $k['nama'], 'jam' => $now]);
}
if ($a['jam_pulang'] === null) {
    if (strtotime($now) - strtotime($a['jam_masuk']) < 60) out(['ok' => false, 'pesan' => 'Sudah absen masuk barusan.', 'nama' => $k['nama'], 'jam' => $now]);
    $pdo->prepare("UPDATE absensi SET jam_pulang=? WHERE id=?")->execute([$now, $a['id']]);
    out(['ok' => true, 'pesan' => 'Absen PULANG berhasil', 'nama' => $k['nama'], 'jam' => $now]);
}
out(['ok' => false, 'pesan' => 'Absen hari ini sudah lengkap (masuk dan pulang).', 'nama' => $k['nama'], 'jam' => $now]);
