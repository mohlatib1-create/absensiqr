<?php
require 'config.php'; admin_required();
$judul = 'Data karyawan';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $aksi = $_POST['aksi'] ?? ''; $id = (int)($_POST['id'] ?? 0);
    try {
        if ($aksi === 'tambah') {
            $nama = trim($_POST['nama'] ?? ''); $un = trim($_POST['username'] ?? ''); $pw = $_POST['password'] ?? '';
            if ($nama === '' || $un === '' || strlen($pw) < 6) throw new RuntimeException('Nama, username, dan password (min. 6 karakter) wajib diisi.');
            $pdo->prepare("INSERT INTO users (nama,username,password,role,jabatan,token) VALUES (?,?,?,'karyawan',?,?)")
                ->execute([$nama, $un, password_hash($pw, PASSWORD_DEFAULT), trim($_POST['jabatan'] ?? ''), bin2hex(random_bytes(16))]);
            set_flash('ok', 'Karyawan ditambahkan.');
        } elseif ($aksi === 'toggle') {
            $pdo->prepare("UPDATE users SET aktif = 1 - aktif WHERE id=? AND role='karyawan'")->execute([$id]);
            set_flash('ok', 'Status karyawan diubah.');
        } elseif ($aksi === 'reset') {
            $pw = $_POST['password'] ?? '';
            if (strlen($pw) < 6) throw new RuntimeException('Password baru minimal 6 karakter.');
            $pdo->prepare("UPDATE users SET password=? WHERE id=? AND role='karyawan'")->execute([password_hash($pw, PASSWORD_DEFAULT), $id]);
            set_flash('ok', 'Password diubah.');
        } elseif ($aksi === 'token') {
            $pdo->prepare("UPDATE users SET token=? WHERE id=? AND role='karyawan'")->execute([bin2hex(random_bytes(16)), $id]);
            set_flash('ok', 'QR baru dibuat. Cetak ulang kartu karyawan ini.');
        } elseif ($aksi === 'hapus') {
            $pdo->prepare("DELETE FROM users WHERE id=? AND role='karyawan'")->execute([$id]);
            set_flash('ok', 'Karyawan dan seluruh datanya dihapus.');
        }
    } catch (PDOException $ex) {
        set_flash('err', $ex->getCode() === '23000' ? 'Username sudah dipakai.' : 'Kesalahan database.');
    } catch (RuntimeException $ex) {
        set_flash('err', $ex->getMessage());
    }
    header('Location: karyawan.php'); exit;
}

$rows = $pdo->query("SELECT id,nama,username,jabatan,aktif FROM users WHERE role='karyawan' ORDER BY nama")->fetchAll();
require 'header.php';
?>
<div class="page-head"><h1>Data karyawan</h1></div>
<section class="panel"><h2>Tambah karyawan</h2>
<form method="post" class="grid-form"><?= csrf_field() ?><input type="hidden" name="aksi" value="tambah">
  <input name="nama" placeholder="Nama lengkap" required>
  <input name="jabatan" placeholder="Jabatan / divisi">
  <input name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password (min. 6)" minlength="6" required>
  <button class="btn" type="submit">Tambah</button>
</form></section>
<section class="panel"><h2>Daftar karyawan</h2>
<?php if (!$rows): ?><p class="muted">Belum ada karyawan.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Nama</th><th>Username</th><th>Jabatan</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr>
  <td><?= e($r['nama']) ?></td><td><?= e($r['username']) ?></td><td><?= e($r['jabatan'] ?: '-') ?></td>
  <td><?= $r['aktif'] ? '<span class="badge b-ok">Aktif</span>' : '<span class="badge b-gray">Nonaktif</span>' ?></td>
  <td class="actions">
    <a href="kartu.php?id=<?= (int)$r['id'] ?>">Kartu QR</a>
    <a href="laporan_bulanan.php?uid=<?= (int)$r['id'] ?>">Rekap</a>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="aksi" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="link" type="submit"><?= $r['aktif'] ? 'Nonaktifkan' : 'Aktifkan' ?></button></form>
    <form method="post" onsubmit="return confirm('Buat QR baru? QR lama tidak berlaku lagi.')"><?= csrf_field() ?><input type="hidden" name="aksi" value="token"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="link" type="submit">QR baru</button></form>
    <form method="post" class="inline-form"><?= csrf_field() ?><input type="hidden" name="aksi" value="reset"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><input type="password" name="password" placeholder="Password baru" minlength="6" required><button class="link" type="submit">Reset</button></form>
    <form method="post" onsubmit="return confirm('Hapus karyawan beserta seluruh data absensinya?')"><?= csrf_field() ?><input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="link danger" type="submit">Hapus</button></form>
  </td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<?php require 'footer.php'; ?>
